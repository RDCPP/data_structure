package cse2010.binary.tree;

public class EmptyTreeException extends RuntimeException {

    public EmptyTreeException(String s) {
        super(s);
    }
}

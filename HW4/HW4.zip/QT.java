public class QT{
    public static void main(String[] args) {
        Quiz q = new Quiz();
        int[] b = {3,6,4,1,3,4,2,5,3,0};
        System.out.println(q.Solve(0, b));
    }
}